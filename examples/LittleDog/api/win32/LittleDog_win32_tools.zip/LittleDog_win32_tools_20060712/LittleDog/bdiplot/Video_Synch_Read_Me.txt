--------------------------------------------------------------------------------------

Instructions on how to perform "Video / Data" Synchronization.

Disclaimer: Synchronizing is primitive, manual, and time consuming at this phase.
            This may change after the system has been tested and used more.

--------------------------------------------------------------------------------------

File-Loading Steps:

   1) load one *.data file.  bdiPlot AVI support hasn�t been tested with more than 
   one data file.  Currently, you must open the data file before opening the AVI file.

   2) load one *.avi file.  bdiPlot AVI support only handles viewing one AVI file.  
   Loading an AVI file requires you to use the �Open� button on the Commands window ->
   Options -> Show Video Window window.

Synchronization Steps:

   0) *** If you�ve never read the "Video Notes" (see bottom of doc), read them first!

   1) Preview the AVI file using the slider on the Video window by holding down
   its right or left arrow buttons.  This should be the only time you need to use the
   slider in this window.   Visually locate and memorize a particular frame (a 
   "targeted video frame") that is so unique that if the data for that frame were seen 
   in the Data window, it would allow you to line up the data and the avi frame.  Write
   down or memorize the targeted video frame number from the caption at the top of the 
   Video Window.   Be sure to select an image frame for which there is actually data 
   in the loaded bdiDataset, as the time durations of the data file and avi file may
   differ substantially.

   2) Ignore the Video window now and instead locate, in the Data window, approximately
   the data for targeted video frame by either: a) clicking the Data window
   and positioning the red cursor on the frame of data that should match the targeted 
   video frame (that video frame may no longer be visible after you click, unless they
   are already synchronized), and/or, b) sliding the red slider on top of the Data 
   window.  The sliding may be necessary in order for the matching data to come into
   view (this will be needed only when you have more bdiDataset data than you have AVI 
   data, and therefore the red Data window slider is short).

   3) Now that the cursor in the Data window is approximately correct, you should 
   slide the red slider that is atop the Data window in small increments until the 
   targeted video frame number displays in the Video window, or least approximately 
   displays.  The timeline cursor will not move when sliding the red slider (unless
   you've scrolled the slider too far), nor will the slider in the Video window.  
   Only the red slider will move and the shown AVI frame will update.  To test how 
   closely things are synchronized, use the Command window's playback buttons (>, >>, 
   <, <<).  If you have problems, make sure that the time cursor hasn't moved in the 
   Data window, as it will attempt to stay on screen when you slide the Data slider.

   4) If the video is rather off, repeat step 3).  If the video is rather close, you
   can use the �Offset +1� or �Offset �1� buttons in the Video window to move the 
   AVI data "behind the scenes" a tad, instead of using the red slider.
   
--------------------------------------------------------------------------------------

*** Video Notes: 

The slider in the Data window turns red when an AVI file is currently loaded to
indicate that it functions differently (than when it is green).  In this mode, the 
length of the red slider shown on the Data window at any given time automatically 
corresponds to the exact time-duration of the AVI file.  A short red slider indicates 
that the AVI is shorter than the data.  A long saturated red bar indicates that the 
AVI is longer than the bdiDataset file.  Once in this mode, the slider in the Data
window no longer supports the "zoom" (the stretching of time).  In this mode, the
slider is a "time synchronizer" only.  Once data has been synchronize, this slider 
should not be used to pan the data, since in this mode it only supports adjustments 
to the synchronization timing, and panning in this mode will alter the timing.

The slider in the Video window is independent from the Data window and does not alter 
anything other than the frame visible in the Video window.  This Video window slider 
should only be used for inspecting the movie before trying to synchronize it.  After
playing a movie in the Video window, the AVI frame will no longer match the time cursor
frame, but at all times, clicking in the Data window moves the cursor to where you 
click, and updates the Video Window such that it shows the AVI frame that is currently
synchronized with the Data window cursor (whether wrongly or rightly synchronized).  
It is recommended that after using the Video sider, you click in the Data Window plot
area (updating the cursor, which resets the Video window's frame).
