
This directory contains the Boston Dynamics Matlab toolbox.
Please refer to the provided user guide on how to use it.
