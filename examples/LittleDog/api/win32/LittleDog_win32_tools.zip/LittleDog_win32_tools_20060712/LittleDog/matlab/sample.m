%
% sample demonstrates how to use the Boston Dynamics matlab
% toolbox to read Boston Dynamics format data files.
%
% The sample script queries the user for a file, selects a variable
% from the file at random and plots this variable. A few file
% statistics are printed to the matlab console.
%
%
  %% Query the user for a file
  [ file, pathname] = uigetfile('*.data','Select Data File');
  if ( file == 0),
    return
  end
  
  %% Read the file
  S = BDI_read_file( strcat( pathname, file ));

  disp( sprintf( '\nFile statistics' ) );
  disp( sprintf( '         name: %s', file ) );
  disp( sprintf( '    modelname: %s', S.model ) );   
  disp( sprintf( '    # of vars: %d', S.n_vars ) );
  disp( sprintf( ' # of samples: %d', S.rows ) );
  disp( sprintf( '   average dt: %d\n', S.dt ) );
  
  %% Pick a random variable
  inx  = min( max( 1, floor( rand * S.n_vars ) ), S.n_vars );
  name = horzcat( S.vars(inx).name );
  
  %% If we don't know the index, we can search by name
  [ i, data ] = BDI_get_var( S, name );
  
  %% Otherwise, we can just grab the data by index
  figure;
  plot( S.t, S.data(:,inx) );
  
  xlabel( 't' );
  ylabel( name );
  title( sprintf( 't vs. %s', name ) );
 