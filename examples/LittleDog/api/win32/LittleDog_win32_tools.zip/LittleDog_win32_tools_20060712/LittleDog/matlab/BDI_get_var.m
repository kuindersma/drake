function [inx, data] = BDI_get_var( S, name )
%BDI_GET_VAR Get a variables data trace by name
%
% Usage
%  [inx, data] = BDI_get_var( S, name )
%
% Description
%  BDI_get_var returns the index and the data of the data whose name
%  matches name. 
%
% Arguments
%     S - structure returned by BDI_read_file containing data
%          file information.
%  name - name of variable whose data we wish to obtain.
%
% Return Values
%   inx - index of column for the desired variable in BDI.data array. 
%  data - column order vector of data for the requested variable
%
% See also BDI_read_file
%

  inx  = 0;
  data = []; 
    
  for j = 1 : S.cols,
  
    if strcmp( name, horzcat( S.vars(j).name ) ),
      inx  = j;
      data = S.data(:, inx);
      return
    end
  
  end
