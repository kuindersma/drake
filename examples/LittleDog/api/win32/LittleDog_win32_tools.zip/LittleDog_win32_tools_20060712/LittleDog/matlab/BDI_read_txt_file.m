function [A] = BDI_read_txt_file(fname)
%
%     Function : 
%  Description : 
%  
%     see Also :
%
  
  fptr = fopen(fname, 'r');
  if fptr ~= -1,
    A    = []; 
    row  = 1;
    col  = 1;
    
    while 1,
      str = fgetl(fptr);

      if str == -1,
	break;    
      end

      %
      % If the line is not a comment, we put the contents of the
      % string into the array we will later return to the user
      %
      if ~strcmp(str(1,1), '#'),
	while 1,
	  % Check if there is something to grab
	  [t, r] = strtok(str);
     
	  % If there is something there add it to the A array
	  if ~isempty(t),
	    if row == 1,
	      A = horzcat(A, 0);
	    elseif col == 1,
	      A = vertcat(A, zeros(1, width));
	    end 
	    
	    A(row, col) = str2num(t);
	    str = r;
	    col = col + 1;
	    
	    % Otherwise setup a few variables for our next line read
	  else
	    width  = col - 1;
	    col = 1;
	    row = row + 1;
	    break;
	  end
	end
      
      end
    end

    return;
  end
  
  A = [];
  return;
