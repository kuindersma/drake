function [ contact ] = BDI_contact_pair_init( contact, S, a_name, b_name )
%BDI_CONTACT_PAIR_INIT
%
% Usage
%  [ contact ] = BDI_contact_pair_init( contact, S, a_name, b_name )
%
% Description
%  BDI_contact_pair_init searches for the contact relationship between
%  entities with names a_name and b_name. S is a structure returned from 
%  BDI_read_file and contact is a structure returned from
%  BDI_contact_pair_create.
%
% See also BDI_contact_pair_create, BDI_contact_pair_destroy
%
    
  str1 = strcat( a_name, '::', b_name, '::dist' );
  str2 = strcat( b_name, '::', a_name, '::dist' );

  [ inx, order ] = find_record_index( S, str1, str2 );
  if ( inx == 0 )
    s = sprintf( 'ERROR: Unable to locate a contact record for %s or %s' );
    disp( s );
    return;
  end
  

  if ( ~order ),
    contact.a_name = a_name;
    contact.b_name = b_name;
  else,
    contact.a_name = b_name;
    contact.b_name = a_name;
  end
    
  contact.dist   = S.data( :, inx   );
  contact.co     = S.data( :, inx+ 1);
  contact.fa     = S.data( :, inx+29); 
  
  contact.a_to_b.cp_x  = S.data( :, inx+ 2);
  contact.a_to_b.cp_y  = S.data( :, inx+ 3);
  contact.a_to_b.cp_z  = S.data( :, inx+ 4);
  contact.a_to_b.cpn_x = S.data( :, inx+ 5);
  contact.a_to_b.cpn_y = S.data( :, inx+ 6);
  contact.a_to_b.cpn_z = S.data( :, inx+ 7);
  contact.a_to_b.f_x   = S.data( :, inx+14);
  contact.a_to_b.f_y   = S.data( :, inx+15);
  contact.a_to_b.f_z   = S.data( :, inx+16);
  contact.a_to_b.ft_x  = S.data( :, inx+17);
  contact.a_to_b.ft_y  = S.data( :, inx+18);
  contact.a_to_b.ft_z  = S.data( :, inx+19);
  contact.a_to_b.fn_x  = S.data( :, inx+20);
  contact.a_to_b.fn_y  = S.data( :, inx+21);
  contact.a_to_b.fn_z  = S.data( :, inx+22);
  contact.a_to_b.t_x   = S.data( :, inx+23);
  contact.a_to_b.t_y   = S.data( :, inx+24);
  contact.a_to_b.t_z   = S.data( :, inx+25);
  contact.a_to_b.poa_x = S.data( :, inx+26);
  contact.a_to_b.poa_y = S.data( :, inx+27);
  contact.a_to_b.poa_z = S.data( :, inx+28);
  
  contact.b_to_a.cp_x  = S.data( :, inx+ 8);
  contact.b_to_a.cp_y  = S.data( :, inx+ 9);
  contact.b_to_a.cp_z  = S.data( :, inx+10);
  contact.b_to_a.cpn_x = S.data( :, inx+11);
  contact.b_to_a.cpn_y = S.data( :, inx+12);
  contact.b_to_a.cpn_z = S.data( :, inx+13);
  contact.b_to_a.f_x   = S.data( :, inx+30);
  contact.b_to_a.f_y   = S.data( :, inx+31);
  contact.b_to_a.f_z   = S.data( :, inx+32);
  contact.b_to_a.ft_x  = S.data( :, inx+33);
  contact.b_to_a.ft_y  = S.data( :, inx+34);
  contact.b_to_a.ft_z  = S.data( :, inx+35);
  contact.b_to_a.fn_x  = S.data( :, inx+36);
  contact.b_to_a.fn_y  = S.data( :, inx+37);
  contact.b_to_a.fn_z  = S.data( :, inx+38);
  contact.b_to_a.t_x   = S.data( :, inx+39);
  contact.b_to_a.t_y   = S.data( :, inx+40);
  contact.b_to_a.t_z   = S.data( :, inx+41);
  contact.b_to_a.poa_x = S.data( :, inx+42);
  contact.b_to_a.poa_y = S.data( :, inx+43);
  contact.b_to_a.poa_z = S.data( :, inx+44);

  return;
  
function [inx, order ] = find_record_index( S, str1, str2 )
    
  for j = 2 : 54: S.cols,
    str = deblank(S.vars(j).name);
    if strcmp( str, str1 ),
      inx   = j;
      order = 0;
      return;
    
    elseif strcmp( str, str2 ),
      inx   = j;
      order = 1;
    end
  end
  
  inx   = 0;
  order = -1;