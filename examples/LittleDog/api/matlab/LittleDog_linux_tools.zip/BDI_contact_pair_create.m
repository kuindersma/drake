function [ contact ] = BDI_contact_pair_create()
%BDI_CONTACT_PAIR_CREATE
%
% Usage
%  [ contact ] = BDI_contact_pair_create()
%
% Description
%  BDI_contact_pair_create, creates an empty contact structure. This
%  structure should be initialized with BDI_contact_pair_init and 
%  destroyed with BDI_contact_pair_destroy.
%
% See also BDI_contact_pair_init, BDI_contact_pair_destroy
%
    
  contact        = [];
  
  contact.dist   = [];
  contact.co     = [];
  contact.fa     = []; 
  contact.a_name = [];
  contact.b_name = [];
  contact.a_to_b = [];
  contact.b_to_a = [];
  
  contact.a_to_b.cp_x  = [];
  contact.a_to_b.cp_y  = [];
  contact.a_to_b.cp_z  = [];
  contact.a_to_b.cpn_x = [];
  contact.a_to_b.cpn_y = [];
  contact.a_to_b.cpn_z = [];
  contact.a_to_b.f_x   = [];
  contact.a_to_b.f_y   = [];
  contact.a_to_b.f_z   = [];
  contact.a_to_b.ft_x  = [];
  contact.a_to_b.ft_y  = [];
  contact.a_to_b.ft_z  = [];
  contact.a_to_b.fn_x  = [];
  contact.a_to_b.fn_y  = [];
  contact.a_to_b.fn_z  = [];
  contact.a_to_b.t_x   = [];
  contact.a_to_b.t_y   = [];
  contact.a_to_b.t_z   = [];
  contact.a_to_b.poa_x = [];
  contact.a_to_b.poa_y = [];
  contact.a_to_b.poa_z = [];
  
  contact.b_to_a.cp_x  = [];
  contact.b_to_a.cp_y  = [];
  contact.b_to_a.cp_z  = [];
  contact.b_to_a.cpn_x = [];
  contact.b_to_a.cpn_y = [];
  contact.b_to_a.cpn_z = [];
  contact.b_to_a.f_x   = [];
  contact.b_to_a.f_y   = [];
  contact.b_to_a.f_z   = [];
  contact.b_to_a.ft_x  = [];
  contact.b_to_a.ft_y  = [];
  contact.b_to_a.ft_z  = [];
  contact.b_to_a.fn_x  = [];
  contact.b_to_a.fn_y  = [];
  contact.b_to_a.fn_z  = [];
  contact.b_to_a.t_x   = [];
  contact.b_to_a.t_y   = [];
  contact.b_to_a.t_z   = [];
  contact.b_to_a.poa_x = [];
  contact.b_to_a.poa_y = [];
  contact.b_to_a.poa_z = [];
  return;