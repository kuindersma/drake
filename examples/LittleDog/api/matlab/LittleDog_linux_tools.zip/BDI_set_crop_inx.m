function BDI_set_crop_inx( varargin )
%BDI_SET_CROP_INX Create a crop file for a dataset
%
% Usage
%  BDI_set_crop_inx( varargin )
%
% Description
%  BDI_set_crop_inx can take a filename or, if no file is provided,
%  will prompt the user for a Boston Dynamics data file. The user
%  is asked for the start/end indeces to crop the data. Indices
%  corresponding to the selected crop in/out points are stored in
%  filename.crop_inx,
%
% See also BDI_get_crop_inx
%
  
  % read in the file name
  if nargin == 0,
    [ file, pathname] = uigetfile('*.data','Select Data File');
    if ( file == 0),
      return
    end

    fname = strcat( pathname, file );
  else 
    fname = horzcat( varargin{:} )
  end

  % concatenate pathname and filename and open file
  A = BDI_read_file( fname );
  samples = A.rows; 
  
  % Figure out crop points
  in  = input(' In Index:  ');
  if isempty( in ) || ( in < 1 ),
    in = 1;
  end

  out = input('Out Index:  ');
  if isempty(out) || ( out > samples ),
    out = samples;
  end

  % Swap if out < in
  if out < in,
    tmp = out;
    out = in;
    in  = tmp;
  end

  % Save the in/out indeces for later use
  filename = strcat(fname,'.crop_inx');
  fid = fopen(filename, 'w');     
  fprintf(fid,'%f\n', in );
  fprintf(fid,'%f\n', out );
  fclose(fid);
