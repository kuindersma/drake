function [BDI] = BDI_read_file_linux(fname)
%
%     Function : [BDI] = BDI_read_file(fname)
%
%  Description : BDI_read_file opens the file specified by fname,
%                returning a structure containing information about
%                the data file.
%    Arguments :
%
%        fname - name of file to be read. NOTE : THE ABSOLUTE PATH
%                TO THE DESIRED FILE MUST BE SPECIFIED, if the
%                datafile  is stored in a directory other than the
%                one containing BDI_read_file. The matlab path must
%                also include the directory containing
%                bdi_read_dataset.dll.
%
%  Return vals :
%
%          BDI - structure containing information about the
%                specified data file.
%
%     see also : BDI_get_var
    
  BDI = [];

  %
  % Read the specified data file.
  %
  [dt, modelname, indiv,  varnames, values ] = bdi_read_dataset(fname);

  %
  % Store various pieces of information about the desired file
  %
  BDI.fname = fname;
  BDI.dt    = dt;
  BDI.model = modelname;	
  BDI.data  = values;

  BDI.rows   = size(values, 1);
  BDI.cols   = size(values, 2);
  BDI.n_vars = BDI.cols;
  BDI.freq   = 1.0/dt;
  BDI.t      = (1:BDI.rows)'/BDI.freq;  

  %
  % Set all variable names
  %
  BDI.vars   = [];
  for i=1:BDI.cols,
    BDI.vars(i).name = varnames(i,:);
    BDI.vars(i).unit = 'units';
  end;

  
