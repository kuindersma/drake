function [ in, out ] = BDI_get_crop_inx( fname )
%BDI_GET_CROP_INX Get crop indeces from crop file
%
% Usage
%  [ in, out ] = BDI_get_crop_inx( fname )
%
% Description
%  BDI_get_crop_inx reads the in/out crop indeces from the file
%  specified by fname. If the fname given to the function is
%  invalid, the function returns 0 for both in and out.
%  
% See also BDI_SET_CROP_INX
%
  in  = 0;
  out = 0;

  fptr = fopen(fname, 'r');
  if fptr ~= -1,
    inx = fscanf(fptr, '%f\n');
    in  = inx(1,1);
    out = inx(2,1);
    fclose(fptr);
  end
